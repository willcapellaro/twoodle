### directories

Last updated 11/11/2022

# files
docguide.md is this readme file, mainly meant for Will to get organized
index.html is the site as a single page
CNAME is a cname directory, which does something?

# directories

# img only has a few images of the quadrants, used in display results > quadrants
# mktimg has an unfurl image

# css has three files
!!!!! this directory requires clean up !!!!! 
one is "oldstyle.css" which appears without a filename right now, let's definitely remove
style.css should be the real one, let's unify to that one

# js has several files
!!!!! this section requires a solid writeup !!!!!
!!!!! these scripts require markup for coherence !!!!!

jquery.js                     - loads jquery
twoodles.js                   - handles actions on twoodles
configurations.js             - handles list behaviors
draggableCode.js              - managed drag and drop
localStorage.js               - manages local storage
recipes.js                    - contains recipes
conditional-logic-draft.js    - helps paint matrix
                              - specifically quadrant labels
results.js                    - paints matrix

understanding as of 11/11/2022

twoodles.js appears to handle matrix logic

# archive
this contains many zipped docs directories, experiments, and can likely be scrapped


---------

to do

!!!!! script section requires a solid writeup !!!!!
!!!!! scripts require markup for coherence !!!!!
!!!!! css directory requires clean up - done, in testing !!!!! 
!!!!! index head sorted, needs regression test !!!!! 
!!!!! bug: quotes don't work in twoodle item labels !!!!!
