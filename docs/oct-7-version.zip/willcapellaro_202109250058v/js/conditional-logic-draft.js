// marcelo, this is the doc that needs a logic improvement. I don't want to have to have to code the same conditions twice.
// see the conditions here, they are all sets of two duplicates
// i'd like to have just a section of mappings, or have a function covert
// this goes along with the button to swap X/Y.

function conditionals(x, y)
{
	x = x.toLowerCase();
	y = y.toLowerCase();
	var texts = [('high ' + y + ' and low ' + x), ('high ' + y + ' and high ' + x), ('low ' + y + ' and high ' + x), ('low ' + y + ' and low ' + x)];
	
	texts = getTexts(x, y, texts, ['urgency', 'importance'], ['schedule', 'focus', 'avoid', 'delegate']);
	
	texts = getTexts(x, y, texts, ['importance', 'ease'], ['luxury', 'strategic', 'distractions', 'high value']);
	
	texts = getTexts(x, y, texts, ['low balance', 'high interest'], ['pay off first', 'pay down first', 'luxury', 'high value']);
	
	return texts;
}
function getTexts(x, y, texts, axis, auxTexts)
{
	if (x == axis[0] && y == axis[1])
	{
		texts = [...auxTexts];
	}
	if (x == axis[1] && y == axis[0])
	{
		//texts = [auxTexts[2], auxTexts[1], auxTexts[0], auxTexts[3]];
		texts = [auxTexts[3], auxTexts[1], auxTexts[2], auxTexts[0]];
	}
	return texts;
}