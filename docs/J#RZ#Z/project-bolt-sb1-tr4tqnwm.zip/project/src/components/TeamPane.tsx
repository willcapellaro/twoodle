import React, { useState, useEffect, useRef } from 'react';
import { ChevronUp, ChevronDown } from 'lucide-react';
import { cn } from '../lib/utils';
import positionTranslations from '../data/position_translation_table.json';

interface TeamPaneProps {
  team: {
    name: string;
    primaryColor: string;
    secondaryColor: string;
    logoUrl: string;
    roster: any[];
  };
  selectedNumber: string;
  onNumberChange: (number: string) => void;
  isActive?: boolean;
  id: string;
}

export const TeamPane: React.FC<TeamPaneProps> = ({
  team,
  selectedNumber,
  onNumberChange,
  isActive,
  id,
}) => {
  const [firstDigit, secondDigit] = selectedNumber.padStart(2, '0').split('');
  const [isFocused, setIsFocused] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (isActive && containerRef.current) {
      containerRef.current.focus();
    }
  }, [isActive]);

  const handleDigitChange = (increment: boolean) => {
    const current = parseInt(selectedNumber);
    const newNumber = increment 
      ? (current + 1) % 100 
      : (current - 1 + 100) % 100;
    onNumberChange(newNumber.toString().padStart(2, '0'));
  };

  const handleSingleDigitChange = (digit: 'first' | 'second', increment: boolean) => {
    const current = selectedNumber.padStart(2, '0');
    const [first, second] = current.split('');
    let newFirst = parseInt(first);
    let newSecond = parseInt(second);

    if (digit === 'first') {
      newFirst = increment ? (newFirst + 1) % 10 : (newFirst - 1 + 10) % 10;
    } else {
      newSecond = increment ? (newSecond + 1) % 10 : (newSecond - 1 + 10) % 10;
    }

    onNumberChange(`${newFirst}${newSecond}`);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (!isFocused) return;

    if (/^\d$/.test(e.key)) {
      const newNumber = (selectedNumber + e.key).slice(-2);
      onNumberChange(newNumber.padStart(2, '0'));
    } else {
      switch (e.key) {
        case 'ArrowUp':
          e.preventDefault();
          handleSingleDigitChange('second', true);
          break;
        case 'ArrowDown':
          e.preventDefault();
          handleSingleDigitChange('second', false);
          break;
        case 'ArrowLeft':
          e.preventDefault();
          handleSingleDigitChange('first', false);
          break;
        case 'ArrowRight':
          e.preventDefault();
          handleSingleDigitChange('first', true);
          break;
      }
    }
  };

  const currentPlayer = team.roster.find(p => p['#'].toString().padStart(2, '0') === selectedNumber);
  const positionFull = currentPlayer ? positionTranslations[currentPlayer.Pos as keyof typeof positionTranslations] || currentPlayer.Pos : "-";

  return (
    <div
      className="flex-1 flex flex-col items-center justify-center p-8"
      style={{
        backgroundColor: team.primaryColor,
        color: team.secondaryColor,
      }}
      id={id}
    >
      <img
        src={team.logoUrl}
        alt={`${team.name} logo`}
        className="w-24 h-24 mb-8 object-contain"
      />
      
      <div className="grid grid-cols-2 gap-4 mb-4">
        {[firstDigit, secondDigit].map((_, index) => (
          <button
            key={`inc-${index}`}
            onClick={() => handleSingleDigitChange(index === 0 ? 'first' : 'second', true)}
            className="p-2 hover:opacity-80 bg-black bg-opacity-20 rounded-lg"
            tabIndex={-1}
          >
            <ChevronUp className="w-6 h-6" />
          </button>
        ))}
      </div>

      <div 
        ref={containerRef}
        className={cn(
          "grid grid-cols-2 gap-4 p-4 rounded-lg transition-all",
          isFocused && "ring-4 ring-white ring-opacity-50"
        )}
        tabIndex={0}
        onFocus={() => setIsFocused(true)}
        onBlur={() => setIsFocused(false)}
        onKeyDown={handleKeyDown}
      >
        {[firstDigit, secondDigit].map((digit, index) => (
          <div
            key={index}
            className="text-[12rem] font-bold flex items-center justify-center leading-none select-none jersey-25-regular number-display"
          >
            {digit}
          </div>
        ))}
      </div>

      <div className="grid grid-cols-2 gap-4 mt-4">
        {[firstDigit, secondDigit].map((_, index) => (
          <button
            key={`dec-${index}`}
            onClick={() => handleSingleDigitChange(index === 0 ? 'first' : 'second', false)}
            className="p-2 hover:opacity-80 bg-black bg-opacity-20 rounded-lg"
            tabIndex={-1}
          >
            <ChevronDown className="w-6 h-6" />
          </button>
        ))}
      </div>

      <div className="mt-8 text-center min-h-[120px]">
        <h2 className="text-3xl font-bold mb-2">{currentPlayer ? currentPlayer.Player : "-"}</h2>
        <p className="text-xl">{positionFull}</p>
      </div>
    </div>
  );
}