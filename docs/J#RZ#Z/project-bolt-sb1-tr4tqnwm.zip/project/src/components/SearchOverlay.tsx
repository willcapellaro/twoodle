import React, { useState, useEffect, useRef } from 'react';
import { Search, X } from 'lucide-react';

interface SearchOverlayProps {
  mode: 'name' | 'position';
  onClose: () => void;
  onSelect: (team: 'chiefs' | 'eagles', number: string) => void;
  chiefsRoster: any[];
  eaglesRoster: any[];
}

export const SearchOverlay: React.FC<SearchOverlayProps> = ({
  mode,
  onClose,
  onSelect,
  chiefsRoster,
  eaglesRoster,
}) => {
  const [query, setQuery] = useState('');
  const [selectedIndex, setSelectedIndex] = useState(0);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    inputRef.current?.focus();
  }, [mode]);

  const results = [
    ...chiefsRoster.map(player => ({ ...player, team: 'chiefs' as const })),
    ...eaglesRoster.map(player => ({ ...player, team: 'eagles' as const }))
  ].filter(player => {
    if (mode === 'name') {
      return player.Player.toLowerCase().includes(query.toLowerCase());
    } else {
      return player.Pos.toLowerCase() === query.toLowerCase();
    }
  });

  const handleKeyDown = (e: React.KeyboardEvent) => {
    switch (e.key) {
      case 'ArrowDown':
        e.preventDefault();
        setSelectedIndex(prev => (prev + 1) % results.length);
        break;
      case 'ArrowUp':
        e.preventDefault();
        setSelectedIndex(prev => (prev - 1 + results.length) % results.length);
        break;
      case 'Enter':
      case ' ':
        e.preventDefault();
        if (results[selectedIndex]) {
          onSelect(
            results[selectedIndex].team,
            results[selectedIndex]['#'].toString().padStart(2, '0')
          );
        }
        break;
      case 'Tab':
        e.preventDefault();
        if (e.shiftKey) {
          setSelectedIndex(prev => (prev - 1 + results.length) % results.length);
        } else {
          setSelectedIndex(prev => (prev + 1) % results.length);
        }
        break;
    }
  };

  const highlightMatch = (text: string) => {
    if (!query) return text;
    
    const regex = new RegExp(`(${query})`, 'gi');
    const parts = text.split(regex);
    
    return parts.map((part, i) => 
      regex.test(part) ? <strong key={i} className="font-bold">{part}</strong> : part
    );
  };

  useEffect(() => {
    // Auto-select if there's only one result
    if (results.length === 1) {
      onSelect(
        results[0].team,
        results[0]['#'].toString().padStart(2, '0')
      );
    }
  }, [results, onSelect]);

  return (
    <div className="fixed inset-0 bg-black bg-opacity-75 flex items-start justify-center pt-20 z-50">
      <div className="bg-white rounded-lg w-full max-w-2xl mx-4">
        <div className="p-4 border-b flex items-center gap-4">
          <Search className="w-5 h-5 text-gray-500" />
          <input
            ref={inputRef}
            type="text"
            placeholder={mode === 'name' ? "Search by name" : "Search by position"}
            className="flex-1 outline-none text-lg"
            value={query}
            onChange={e => setQuery(e.target.value)}
            onKeyDown={handleKeyDown}
          />
          <div className="text-sm text-gray-500">
            {mode === 'name' ? 'Name Search' : 'Position Search'}
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-full"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
        
        <div className="max-h-[60vh] overflow-y-auto">
          {results.map((result, index) => (
            <button
              key={`${result.team}-${result['#']}`}
              className={`w-full p-4 flex items-center gap-4 hover:bg-gray-100 ${
                index === selectedIndex ? 'bg-blue-50' : ''
              }`}
              onClick={() => onSelect(result.team, result['#'].toString().padStart(2, '0'))}
              style={{
                color: result.team === 'chiefs' ? '#E31837' : '#004C54'
              }}
            >
              <span className="w-16 text-center font-mono">#{result['#']}</span>
              <span className="flex-1">{highlightMatch(result.Player)}</span>
              <span className="w-20 text-right">{result.Pos}</span>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}