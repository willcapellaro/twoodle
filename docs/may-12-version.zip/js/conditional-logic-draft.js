//i may not have the javascript syntax perfect here, but the logic should work

if (y == 'importance' && x == "urgency") {
	topleft = 'schedule';
	topright = 'focus';
	bottomleft = 'avoid';
	bottomright = 'delegate';
} else if (y == 'urgency' && x == "importance") {
	topleft = 'avoid';
	topright = 'focus';
	bottomleft = 'schedule';
	bottomright = 'delegate';
} else if (y == 'ease' && x == "importance") {
	topleft = 'luxury';
	topright = 'strategic';
	bottomleft = 'distractions';
	bottomright = 'high value';
} else if (y == 'importance' && x == "ease") {
	topleft = 'distractions';
	topright = 'strategic';
	bottomleft = 'luxury';
	bottomright = 'high value';
} else if (y == 'high interest' && x == "low balance") {
	topleft = 'pay off first';
	topright = 'pay down first';
	bottomleft = 'luxury';
	bottomright = 'high value';
} else {
	topleft = 'high' + y " and low " + x;
	topright = 'high' + y " and high " + x;
	bottomleft = 'low' + y " and high " + x;
	bottomright = 'low' + y " and low " + x;
}