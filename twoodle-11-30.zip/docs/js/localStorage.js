var userID;
var flagShareUpdate = true;
var selectedTab = 'quadrants';
var twoodles;
var items = [];
window.addEventListener('storage', () => {});
function saveAxisNames()
{
	if ((document.getElementById('yAxis_name').value != document.getElementById('xAxis_name').value) && twoodles[selectedTwoodleIndex])
	{
		twoodles[selectedTwoodleIndex]['defaultX'] = xAxisName;
		twoodles[selectedTwoodleIndex]['defaultY'] = yAxisName;
	}
	checkLblRecipes();
}
function saveValues()
{
	saveAxisNames();
	localStorage.setItem('twoodles', JSON.stringify({'twoodles': twoodles}));
}
function loadValues()
{
	selectedTwoodle = 0;
	if (localStorage.getItem('twoodles'))
    {
		twoodles = JSON.parse(localStorage.getItem('twoodles'))['twoodles'];
		if (!twoodles.length)
		{
			twoodles = [{
				'id' : 0, 
				'name' : 'Twoodle 1', 
				'defaultY' : recipes[0]['defaultY'], 
				'defaultX' : recipes[0]['defaultX'], 
				'items' : [], 
				'xValues' : [], 
				'yValues' : []
			}];
		}
		else
		{
			yValues = twoodles[0]['yValues'];
			xValues = twoodles[0]['xValues'];
			items = twoodles[0]['items'];
		}
	}
	else
	{
		localStorage.setItem('twoodles', JSON.stringify({'twoodles' : [{
			'id' : 0, 
			'name' : 'Twoodle 1', 
			'defaultY' : recipes[0]['defaultY'], 
			'defaultX' : recipes[0]['defaultX'], 
			'items' : [], 
			'xValues' : [], 
			'yValues' : []
		}]}));
		twoodles = JSON.parse(localStorage.getItem('twoodles'))['twoodles'];
	}
	fillTwoodlesSelect();
	flagShareUpdate = false;
	fillItemsList(twoodles[0]['items']);
	yAxisName = twoodles[0]['defaultY'];
	xAxisName = twoodles[0]['defaultX'];
	document.getElementById('yAxis_name').value = twoodles[0]['defaultY'];
	document.getElementById('xAxis_name').value = twoodles[0]['defaultX'];
	selectedTwoodleIndex = 0;
	flagShareUpdate = true;
}
function fillTwoodlesSelect(changeIndex = true)
{
	var html = '<option id="optSlcTwoodles_new" onclick="displayNewTwoodleMenu();">+ New Twoodle</option>';
	for (var i = 0; i < twoodles.length; i++)
	{
		html += '<option id="optSlcTwoodles_' + twoodles[i]['id'] + '">' + twoodles[i]['name'] + '</option>';
	}
	document.getElementById('slcTwoodles').innerHTML = html;
	if (changeIndex)
	{
		document.getElementById('slcTwoodles').selectedIndex = selectedTwoodleIndex + 1;
	}
	if (document.getElementById('slcTwoodles').length == -1)
	{
		document.getElementById('slcTwoodles').selectedIndex = document.getElementById('slcTwoodles').length - 1;
	}
}
function localStorageSelected(selectedIndex)
{
	if (selectedIndex)
	{
		displayLocalStorage();
	}
	else
	{
		clearValues();
	}
}
function displayLocalStorage(tab = 'readable')
{
	document.getElementById('clipboardInfo').innerHTML = '';
	selectedTab = tab;
	var localStorageText = '';
	xValues = JSON.parse(localStorage.getItem('twoodles'))['twoodles'][selectedTwoodleIndex]['xValues'];
	yValues = JSON.parse(localStorage.getItem('twoodles'))['twoodles'][selectedTwoodleIndex]['yValues'];
	xAxisName = JSON.parse(localStorage.getItem('twoodles'))['twoodles'][selectedTwoodleIndex]['defaultX'];
	yAxisName = JSON.parse(localStorage.getItem('twoodles'))['twoodles'][selectedTwoodleIndex]['defaultY'];
	items = JSON.parse(localStorage.getItem('twoodles'))['twoodles'][selectedTwoodleIndex]['items'];
	if (xValues || yValues)
	{
		if (tab == 'readable')
		{
			localStorageText = 'Highest to Lowest ' + xAxisName + '<br><br>';
			for (var i = 0; i < xValues.length; i++)
			{
				for (var j = 0; j < items.length; j++)
				{
					if (xValues[i]['index'] == items[j]['index'])
					{
						localStorageText += items[j]['name'] + '<br>';
					}
				}
			}
			localStorageText += '<br>Highest to Lowest ' + yAxisName + '<br><br>';
			for (var i = 0; i < yValues.length; i++)
			{
				for (var j = 0; j < items.length; j++)
				{
					if (yValues[i]['index'] == items[j]['index'])
					{
						localStorageText += items[j]['name'] + '<br>';
					}
				}
			}
			document.getElementById('readableBtn').classList.add('resultsModalActiveTab');
			document.getElementById('quadrantsBtn').classList.remove('resultsModalActiveTab');
			document.getElementById('codeBtn').classList.remove('resultsModalActiveTab');
		}
		if (tab == 'code')
		{
			var recipeIndex = checkLblRecipes();
			if (recipeIndex != -1)
			{
				localStorageText = 'recipe id: ' + recipeIndex + '<br>';
				localStorageText += 'recipe Name: ' + recipes[recipeIndex]['recipeName'] + '<br>';
				if (recipes[recipeIndex]['defaultXY'])
				{
					localStorageText += 'defaultXY: Yes<br><br>';
				}
				else
				{
					localStorageText += 'defaultXY: No<br><br>';
				}
			}
			localStorageText += 'xAxisName: ' + xAxisName + '<br>';
			localStorageText += 'yAxisName: ' + yAxisName + '<br><br>';

			if (items && items.length)
			{
				localStorageText += 'items:<br>';
				for (var i = 0; i < items.length; i++)
		    	{
		    		localStorageText += 'name: ' + items[i]['name'] + ', index: ' + items[i]['index'] + '<br>';
		    	}
		    	localStorageText += '<br>';
			}
			
			if (xValues && xValues.length)
			{
				localStorageText += 'xValues:<br>';
				for (var i = 0; i < xValues.length; i++)
		    	{
		    		localStorageText += 'value: ' + xValues[i]['value'] + ', index: ' + xValues[i]['index'] + '<br>';
		    	}
		    	localStorageText += '<br>';
			}

			if (yValues && yValues.length)
			{
				localStorageText += 'yValues:<br>';
				for (var i = 0; i < yValues.length; i++)
		    	{
		    		localStorageText += 'value: ' + yValues[i]['value'] + ', index: ' + yValues[i]['index'] + '<br>';
		    	}
			}
			document.getElementById('readableBtn').classList.remove('resultsModalActiveTab');
			document.getElementById('quadrantsBtn').classList.remove('resultsModalActiveTab');
			document.getElementById('codeBtn').classList.add('resultsModalActiveTab');
		}
		if (tab == 'quadrants')
		{
			var quadrantsTexts = conditionals(xAxisName, yAxisName);
			var itemsNE = '';
			var itemsNW = '';
			var itemsSE = '';
			var itemsSW = '';
			for (var i = 0; i < items.length; i++)
            {
            	for (var j = 0; j < yValues.length; j++)
            	{
            		for (var k = 0; k < xValues.length; k++)
            		{
		                if (yValues[j]['index'] == xValues[k]['index'])
		                {
		                	if (yValues[j]['value'] >= 50)
		                	{
		                		if (xValues[k]['value'] >= 50)
		                		{
		                			if (xValues[k]['index'] == items[i]['index'])
        							{
        								itemsNE += items[i]['name'] + '<br>';
        							}
		                		}
		                		else
		                		{
		                			if (yValues[j]['index'] == items[i]['index'])
        							{
        								itemsNW += items[i]['name'] + '<br>';
        							}
		                		}
		                	}
		                	else
		                	{
		                		if (xValues[k]['value'] >= 50)
		                		{
		                			if (xValues[k]['index'] == items[i]['index'])
        							{
        								itemsSE += items[i]['name'] + '<br>';
        							}
		                		}
		                		else
		                		{
		                			if (yValues[j]['index'] == items[i]['index'])
        							{
        								itemsSW += items[i]['name'] + '<br>';
        							}
		                		}
		                	}
		                }
		        	}
	            }
        	}

			if (!itemsNE.length)
			{
        		itemsNE = 'No items<br>';
			}
			if (!itemsNW.length)
			{
				itemsNW = 'No items<br>';
			}
			if (!itemsSE.length)
			{
				itemsSE = 'No items<br>';
			}
			if (!itemsSW.length)
			{
				itemsSW = 'No items<br>';
			}

			localStorageText = '<img src="./img/quadrantNE.png">    ' + quadrantsTexts[0] + '<br>';
			localStorageText += itemsNE + '<br>';

			localStorageText += '<img src="./img/quadrantNW.png">    ' + quadrantsTexts[1] + '<br>';
			localStorageText += itemsNW + '<br>';

			localStorageText += '<img src="./img/quadrantSE.png">    ' + quadrantsTexts[2] + '<br>';
			localStorageText += itemsSE + '<br>';

			localStorageText += '<img src="./img/quadrantSW.png">    ' + quadrantsTexts[3] + '<br>';
			localStorageText += itemsSW + '<br>';

			document.getElementById('readableBtn').classList.remove('resultsModalActiveTab');
			document.getElementById('quadrantsBtn').classList.add('resultsModalActiveTab');
			document.getElementById('codeBtn').classList.remove('resultsModalActiveTab');
		}
	}
	document.getElementById('localStorageContents').innerHTML = localStorageText;
}
function clearValues()
{
	document.getElementById('modalClear').style.display = 'none';
	idsOrder = [];
	itemMoved = -1;
	validItemsNames = true;
	validAxisNames = true;

	document.getElementById('yAxis_name').value = 'importance';
	document.getElementById('xAxis_name').value = 'urgency';
	yAxisName = document.getElementById('yAxis_name').value;
	xAxisName = document.getElementById('xAxis_name').value;
	document.getElementById('itemsList').innerHTML = '';
	twoodles = [{
		'id' : 0, 
		'name' : 'Twoodle 1', 
		'defaultY' : recipes[0]['defaultY'], 
		'defaultX' : recipes[0]['defaultX'], 
		'items' : [], 
		'xValues' : [], 
		'yValues' : []
	}];
	document.getElementById('yAxis_name').value = twoodles[0]['defaultY'];
	document.getElementById('xAxis_name').value = twoodles[0]['defaultX'];
	saveValues();
	if (document.getElementById("resultsDiv").style.display == "block")
	{
		menuItemClicked('see');
	}
	fillTwoodlesSelect();
	selectedTwoodleIndex = 0;
	selectedTwoodle = twoodles[0].id;
	document.getElementById('slcTwoodles').selectedIndex = 1;
	yAxisName = document.getElementById('yAxis_name').value;
	xAxisName = document.getElementById('xAxis_name').value;
	checkLblRecipes();
}
function copyContent()
{
	if (navigator.clipboard)
	{
		var text = document.getElementById('localStorageContents').innerText;
		var aux = '';
		var firstChar = false;
		for (var i = 0; i < text.length; i++)
		{
			if (!firstChar)
			{
				if (text[i] != ' ')
				{
					firstChar = true;
				}
			}
			if (firstChar)
			{
				aux += text[i];
				if (text[i] == '\n')
				{
					firstChar = false;
				}
			}
		}
		text = aux;
		if (aux[aux.length - 1] == '\n')
		{
			var finalIndex;
			for (var i = (aux.length - 1); i >= 0; i--)
			{
				if (aux[i] != '\n')
				{
					finalIndex = i;
					i = -1;
				}
			}
			text = '';
			for (var i = 0; i < aux.length; i++)
			{
				if (i <= finalIndex)
				{
					text += aux[i];
				}
			}
		}
		navigator.clipboard.writeText(text);
		document.getElementById('clipboardInfo').classList.add('clipboardInfoSuccess');
		document.getElementById('clipboardInfo').classList.remove('clipboardInfoError');
		document.getElementById('clipboardInfo').innerHTML = 'Content Copied.';
	}
	else
	{
		document.getElementById('clipboardInfo').classList.remove('clipboardInfoSuccess');
		document.getElementById('clipboardInfo').classList.add('clipboardInfoError');
		document.getElementById('clipboardInfo').innerHTML = 'Clipboard not available.';
	}
}
function swap()
{
	var auxY = twoodles[selectedTwoodleIndex]['defaultY'];
	var auxX = twoodles[selectedTwoodleIndex]['defaultX'];
	document.getElementById('yAxis_name').value = auxX;
	document.getElementById('xAxis_name').value = auxY;
	twoodles[selectedTwoodleIndex]['defaultY'] = document.getElementById('yAxis_name').value;
	twoodles[selectedTwoodleIndex]['defaultX'] = document.getElementById('xAxis_name').value;
	yAxisName = document.getElementById('yAxis_name').value;
	xAxisName = document.getElementById('xAxis_name').value;
	checkLblRecipes();
	for (var i = 0; i < twoodles[selectedTwoodleIndex]['xValues'].length; i++)
	{
		var auxValue = twoodles[selectedTwoodleIndex]['xValues'][i];
		for (var j = 0; j < twoodles[selectedTwoodleIndex]['yValues'].length; j++)
		{
			if (twoodles[selectedTwoodleIndex]['xValues'][i]['index'] == twoodles[selectedTwoodleIndex]['yValues'][j]['index'])
			{
				twoodles[selectedTwoodleIndex]['xValues'][i] = twoodles[selectedTwoodleIndex]['yValues'][j];
				twoodles[selectedTwoodleIndex]['yValues'][j] = auxValue;
			}
		}
	}
	var changes = true;
	while (changes)
	{
		changes = false;
		for (var i = 0; i < twoodles[selectedTwoodleIndex]['xValues'].length - 1; i++)
		{
			if (twoodles[selectedTwoodleIndex]['xValues'][i]['value'] < twoodles[selectedTwoodleIndex]['xValues'][i + 1]['value'])
			{
				var auxValue = twoodles[selectedTwoodleIndex]['xValues'][i];
				twoodles[selectedTwoodleIndex]['xValues'][i] = twoodles[selectedTwoodleIndex]['xValues'][i + 1];
				twoodles[selectedTwoodleIndex]['xValues'][i + 1] = auxValue;
				changes = true;
			}
		}
	}
	changes = true;
	while (changes)
	{
		changes = false;
		for (var i = 0; i < twoodles[selectedTwoodleIndex]['yValues'].length - 1; i++)
		{
			if (twoodles[selectedTwoodleIndex]['yValues'][i]['value'] < twoodles[selectedTwoodleIndex]['yValues'][i + 1]['value'])
			{
				var auxValue = twoodles[selectedTwoodleIndex]['yValues'][i];
				twoodles[selectedTwoodleIndex]['yValues'][i] = twoodles[selectedTwoodleIndex]['yValues'][i + 1];
				twoodles[selectedTwoodleIndex]['yValues'][i + 1] = auxValue;
				changes = true;
			}
		}
	}
	saveValues();
}